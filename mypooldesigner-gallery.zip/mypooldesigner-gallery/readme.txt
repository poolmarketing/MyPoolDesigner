=== MyPoolDesigner Gallery ===
Contributors: mypooldesigner
Donate link: https://mypooldesigner.ai/
Tags: gallery, pool design, AI, responsive, lightbox
Requires at least: 5.0
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 2.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Display your MyPoolDesigner.ai designs in beautiful responsive galleries with lightbox functionality.

== Description ==

MyPoolDesigner Gallery is a WordPress plugin that allows you to display your AI-generated pool designs from MyPoolDesigner.ai in beautiful, responsive galleries on your WordPress website.

= Features =

* **Responsive Grid Layout** - Displays galleries in a 4-column responsive grid that adapts to mobile devices
* **Lightbox Modal** - Click images for full-size viewing with navigation controls
* **Multi-Image Support** - Navigate through multiple design images with arrow controls
* **Video Support** - Play videos and presentations directly in the lightbox
* **Pagination** - Handle large galleries with customizable pagination
* **Light & Dark Themes** - Choose between light and dark display themes
* **Multiple Shortcodes** - Display galleries, collections, individual designs, and videos
* **Public Designs Only** - Automatically shows only your public designs for privacy

= Shortcodes =

* `[mypooldesigner-gallery]` - Display all your public designs
* `[mypooldesigner-gallery theme="dark"]` - Dark theme gallery
* `[mypooldesigner-gallery pagination="20"]` - Show 20 items per page
* `[mypooldesigner-collection number="1"]` - Display a specific collection
* `[mypooldesigner-design id="123"]` - Display a single design
* `[mypooldesigner-videos]` - Display your video designs

= Requirements =

* MyPoolDesigner.ai account with API key
* WordPress 5.0 or higher
* PHP 7.4 or higher

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/mypooldesigner-gallery` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Go to WordPress Admin → MyPoolDesigner to configure your API key.
4. Get your API key from your MyPoolDesigner.ai account dashboard.
5. Add shortcodes to your posts or pages to display galleries.

== Frequently Asked Questions ==

= Do I need a MyPoolDesigner.ai account? =

Yes, you need a MyPoolDesigner.ai account and API key to use this plugin. The plugin displays designs from your MyPoolDesigner.ai account.

= Are my private designs displayed? =

No, the plugin only displays designs marked as "public" in your MyPoolDesigner.ai account for privacy protection.

= Can I customize the gallery appearance? =

Yes, you can choose between light and dark themes, adjust pagination, and use CSS to further customize the appearance.

= Does it work on mobile devices? =

Yes, the gallery is fully responsive and works beautifully on mobile devices, tablets, and desktops.

= Can I display videos? =

Yes, the plugin supports video and presentation playback in the lightbox modal.

== Screenshots ==

1. Responsive gallery grid showing pool designs
2. Lightbox modal with image navigation
3. Admin settings page with API key configuration
4. Dark theme gallery display
5. Video playback in lightbox modal

== Changelog ==

= 1.2.0 =
* WordPress.org repository compliance
* Removed external CDN dependencies
* Added proper output escaping and nonce verification
* Removed debug functions for production readiness
* Enhanced security and code quality
* Added comprehensive readme.txt
* Improved responsive design

= 1.1.0 =
* Added multi-image navigation
* Video and presentation support
* Dark theme option
* Collection display shortcode
* Pagination controls
* Mobile responsiveness improvements

= 1.0.0 =
* Initial release
* Basic gallery functionality
* API integration with MyPoolDesigner.ai
* Responsive grid layout
* Lightbox image viewing

== Upgrade Notice ==

= 1.2.0 =
This version meets WordPress.org repository standards with improved security, removed external dependencies, and enhanced code quality.

== Support ==

For support, please visit https://mypooldesigner.ai/support or contact our support team.

== Privacy Policy ==

This plugin connects to MyPoolDesigner.ai API to fetch your designs. Only public designs are displayed. Your API key is stored securely in your WordPress database and is never shared with third parties.

== External Services ==

This plugin connects to MyPoolDesigner.ai API (https://mypooldesigner.ai/api/) to fetch your pool designs. By using this plugin, you agree to MyPoolDesigner.ai's Terms of Service and Privacy Policy available at https://mypooldesigner.ai/terms and https://mypooldesigner.ai/privacy.